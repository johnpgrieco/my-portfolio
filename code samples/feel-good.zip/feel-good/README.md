![App Brewery Banner](https://github.com/londonappbrewery/Images/blob/master/AppBreweryBanner.png)


# Feel Good 🎱

## The app

Whenever you need a pick-me-up, open the app and click on it for an idea!

![End Banner](https://github.com/londonappbrewery/Images/blob/master/readme-end-banner.png)
